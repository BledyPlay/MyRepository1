---
name: Advanced
about: For developers and experienced users only
title: ''
labels: ''
assignees: ''

---

## Please do not ask for help or report compatibility regressions here, use [RPCS3 Discord server](https://discord.me/RPCS3) or [forums](https://forums.rpcs3.net/) instead.

You're using the advanced template. You're expected to know what to write in order to fill in all the required information for proper report.

If you're unsure on what to do, please return back to the issue type selection and choose different category.