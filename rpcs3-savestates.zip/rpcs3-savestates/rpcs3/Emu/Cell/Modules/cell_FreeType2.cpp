#include "stdafx.h"
#include "Emu/Cell/PPUModule.h"

LOG_CHANNEL(cell_FreeType2);

// Functions
error_code cellFreeType2Ex()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Activate_Size()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Add_Default_Modules()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Add_Module()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Alloc()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Angle_Diff()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Atan2()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Attach_File()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Attach_Stream()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Bitmap_Convert()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Bitmap_Copy()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Bitmap_Done()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Bitmap_Embolden()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Bitmap_New()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_CMapCache_Lookup()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_CMapCache_New()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_CeilFix()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_ImageCache_Lookup()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_ImageCache_New()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_Manager_Done()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_Manager_LookupFace()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_Manager_LookupSize()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_Manager_New()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_Manager_RemoveFaceID()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_Node_Unref()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Cos()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_SBitCache_Lookup()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FTC_SBitCache_New()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_DivFix()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Done_Face()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Done_FreeType()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Done_Glyph()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Done_Library()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Done_Size()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_FloorFix()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Free()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_BDF_Charset_ID()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_BDF_Property()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Char_Index()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Charmap_Index()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_CMap_Language_ID()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_First_Char()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Glyph()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Glyph_Name()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Kerning()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_MM_Var()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Module()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Multi_Master()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Name_Index()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Next_Char()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_PFR_Advance()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_PFR_Kerning()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_PFR_Metrics()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Postscript_Name()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_PS_Font_Info()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_PS_Font_Private()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Renderer()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Sfnt_Name()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Sfnt_Name_Count()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Sfnt_Table()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_SubGlyph_Info()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_Track_Kerning()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_TrueType_Engine_Type()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_X11_Font_Format()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Get_WinFNT_Header()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Glyph_Copy()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Glyph_Get_CBox()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_GlyphSlot_Own_Bitmap()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Glyph_Stroke()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Glyph_StrokeBorder()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Glyph_To_Bitmap()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Glyph_Transform()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Has_PS_Glyph_Names()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Init_FreeType()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Library_Version()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_List_Add()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_List_Finalize()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_List_Find()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_List_Insert()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_List_Iterate()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_List_Remove()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_List_Up()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Load_Char()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Load_Glyph()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Load_Sfnt_Table()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Matrix_Invert()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Matrix_Multiply()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_MulDiv()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_MulFix()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_New_Face()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_New_Library()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_New_Memory()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_New_Memory_Face()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_New_Size()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Open_Face()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_OpenType_Free()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_OpenType_Validate()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Check()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Copy()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Decompose()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Done()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Embolden()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Get_BBox()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Get_Bitmap()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Get_CBox()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_GetInsideBorder()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Get_Orientation()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_GetOutsideBorder()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_New()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Render()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Reverse()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Transform()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Outline_Translate()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Realloc()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Remove_Module()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Render_Glyph()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Request_Size()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_RoundFix()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Select_Charmap()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Select_Size()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_Charmap()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_Char_Size()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_Debug_Hook()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_MM_Blend_Coordinates()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_MM_Design_Coordinates()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_Pixel_Sizes()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_Renderer()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_Transform()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_Var_Blend_Coordinates()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Set_Var_Design_Coordinates()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Sfnt_Table_Info()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Sin()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stream_OpenGzip()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stream_OpenLZW()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_BeginSubPath()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_ConicTo()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_CubicTo()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_Done()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_EndSubPath()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_Export()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_ExportBorder()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_GetBorderCounts()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_GetCounts()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_LineTo()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_New()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_ParseOutline()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_Rewind()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Stroker_Set()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Tan()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Vector_From_Polar()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Vector_Length()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Vector_Polarize()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Vector_Rotate()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Vector_Transform()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}

error_code FT_Vector_Unit()
{
	UNIMPLEMENTED_FUNC(cell_FreeType2);
	return CELL_OK;
}


DECLARE(ppu_module_manager::cell_FreeType2)("cell_FreeType2", []()
{
	REG_FUNC(cell_FreeType2, cellFreeType2Ex);

	REG_FUNC(cell_FreeType2, FT_Activate_Size);
	REG_FUNC(cell_FreeType2, FT_Add_Default_Modules);
	REG_FUNC(cell_FreeType2, FT_Add_Module);
	REG_FUNC(cell_FreeType2, FT_Alloc);
	REG_FUNC(cell_FreeType2, FT_Angle_Diff);
	REG_FUNC(cell_FreeType2, FT_Atan2);
	REG_FUNC(cell_FreeType2, FT_Attach_File);
	REG_FUNC(cell_FreeType2, FT_Attach_Stream);
	REG_FUNC(cell_FreeType2, FT_Bitmap_Convert);
	REG_FUNC(cell_FreeType2, FT_Bitmap_Copy);
	REG_FUNC(cell_FreeType2, FT_Bitmap_Done);
	REG_FUNC(cell_FreeType2, FT_Bitmap_Embolden);
	REG_FUNC(cell_FreeType2, FT_Bitmap_New);
	REG_FUNC(cell_FreeType2, FTC_CMapCache_Lookup);
	REG_FUNC(cell_FreeType2, FTC_CMapCache_New);
	REG_FUNC(cell_FreeType2, FT_CeilFix);
	REG_FUNC(cell_FreeType2, FTC_ImageCache_Lookup);
	REG_FUNC(cell_FreeType2, FTC_ImageCache_New);
	REG_FUNC(cell_FreeType2, FTC_Manager_Done);
	REG_FUNC(cell_FreeType2, FTC_Manager_LookupFace);
	REG_FUNC(cell_FreeType2, FTC_Manager_LookupSize);
	REG_FUNC(cell_FreeType2, FTC_Manager_New);
	REG_FUNC(cell_FreeType2, FTC_Manager_RemoveFaceID);
	REG_FUNC(cell_FreeType2, FTC_Node_Unref);
	REG_FUNC(cell_FreeType2, FT_Cos);
	REG_FUNC(cell_FreeType2, FTC_SBitCache_Lookup);
	REG_FUNC(cell_FreeType2, FTC_SBitCache_New);
	REG_FUNC(cell_FreeType2, FT_DivFix);
	REG_FUNC(cell_FreeType2, FT_Done_Face);
	REG_FUNC(cell_FreeType2, FT_Done_FreeType);
	REG_FUNC(cell_FreeType2, FT_Done_Glyph);
	REG_FUNC(cell_FreeType2, FT_Done_Library);
	REG_FUNC(cell_FreeType2, FT_Done_Size);
	REG_FUNC(cell_FreeType2, FT_FloorFix);
	REG_FUNC(cell_FreeType2, FT_Free);
	REG_FUNC(cell_FreeType2, FT_Get_BDF_Charset_ID);
	REG_FUNC(cell_FreeType2, FT_Get_BDF_Property);
	REG_FUNC(cell_FreeType2, FT_Get_Char_Index);
	REG_FUNC(cell_FreeType2, FT_Get_Charmap_Index);
	REG_FUNC(cell_FreeType2, FT_Get_CMap_Language_ID);
	REG_FUNC(cell_FreeType2, FT_Get_First_Char);
	REG_FUNC(cell_FreeType2, FT_Get_Glyph);
	REG_FUNC(cell_FreeType2, FT_Get_Glyph_Name);
	REG_FUNC(cell_FreeType2, FT_Get_Kerning);
	REG_FUNC(cell_FreeType2, FT_Get_MM_Var);
	REG_FUNC(cell_FreeType2, FT_Get_Module);
	REG_FUNC(cell_FreeType2, FT_Get_Multi_Master);
	REG_FUNC(cell_FreeType2, FT_Get_Name_Index);
	REG_FUNC(cell_FreeType2, FT_Get_Next_Char);
	REG_FUNC(cell_FreeType2, FT_Get_PFR_Advance);
	REG_FUNC(cell_FreeType2, FT_Get_PFR_Kerning);
	REG_FUNC(cell_FreeType2, FT_Get_PFR_Metrics);
	REG_FUNC(cell_FreeType2, FT_Get_Postscript_Name);
	REG_FUNC(cell_FreeType2, FT_Get_PS_Font_Info);
	REG_FUNC(cell_FreeType2, FT_Get_PS_Font_Private);
	REG_FUNC(cell_FreeType2, FT_Get_Renderer);
	REG_FUNC(cell_FreeType2, FT_Get_Sfnt_Name);
	REG_FUNC(cell_FreeType2, FT_Get_Sfnt_Name_Count);
	REG_FUNC(cell_FreeType2, FT_Get_Sfnt_Table);
	REG_FUNC(cell_FreeType2, FT_Get_SubGlyph_Info);
	REG_FUNC(cell_FreeType2, FT_Get_Track_Kerning);
	REG_FUNC(cell_FreeType2, FT_Get_TrueType_Engine_Type);
	REG_FUNC(cell_FreeType2, FT_Get_WinFNT_Header);
	REG_FUNC(cell_FreeType2, FT_Get_X11_Font_Format);
	REG_FUNC(cell_FreeType2, FT_Glyph_Copy);
	REG_FUNC(cell_FreeType2, FT_Glyph_Get_CBox);
	REG_FUNC(cell_FreeType2, FT_GlyphSlot_Own_Bitmap);
	REG_FUNC(cell_FreeType2, FT_Glyph_Stroke);
	REG_FUNC(cell_FreeType2, FT_Glyph_StrokeBorder);
	REG_FUNC(cell_FreeType2, FT_Glyph_To_Bitmap);
	REG_FUNC(cell_FreeType2, FT_Glyph_Transform);
	REG_FUNC(cell_FreeType2, FT_Has_PS_Glyph_Names);
	REG_FUNC(cell_FreeType2, FT_Init_FreeType);
	REG_FUNC(cell_FreeType2, FT_Library_Version);
	REG_FUNC(cell_FreeType2, FT_List_Add);
	REG_FUNC(cell_FreeType2, FT_List_Finalize);
	REG_FUNC(cell_FreeType2, FT_List_Find);
	REG_FUNC(cell_FreeType2, FT_List_Insert);
	REG_FUNC(cell_FreeType2, FT_List_Iterate);
	REG_FUNC(cell_FreeType2, FT_List_Remove);
	REG_FUNC(cell_FreeType2, FT_List_Up);
	REG_FUNC(cell_FreeType2, FT_Load_Char);
	REG_FUNC(cell_FreeType2, FT_Load_Glyph);
	REG_FUNC(cell_FreeType2, FT_Load_Sfnt_Table);
	REG_FUNC(cell_FreeType2, FT_Matrix_Invert);
	REG_FUNC(cell_FreeType2, FT_Matrix_Multiply);
	REG_FUNC(cell_FreeType2, FT_MulDiv);
	REG_FUNC(cell_FreeType2, FT_MulFix);
	REG_FUNC(cell_FreeType2, FT_New_Face);
	REG_FUNC(cell_FreeType2, FT_New_Library);
	REG_FUNC(cell_FreeType2, FT_New_Memory);
	REG_FUNC(cell_FreeType2, FT_New_Memory_Face);
	REG_FUNC(cell_FreeType2, FT_New_Size);
	REG_FUNC(cell_FreeType2, FT_Open_Face);
	REG_FUNC(cell_FreeType2, FT_OpenType_Free);
	REG_FUNC(cell_FreeType2, FT_OpenType_Validate);
	REG_FUNC(cell_FreeType2, FT_Outline_Check);
	REG_FUNC(cell_FreeType2, FT_Outline_Copy);
	REG_FUNC(cell_FreeType2, FT_Outline_Decompose);
	REG_FUNC(cell_FreeType2, FT_Outline_Done);
	REG_FUNC(cell_FreeType2, FT_Outline_Embolden);
	REG_FUNC(cell_FreeType2, FT_Outline_Get_BBox);
	REG_FUNC(cell_FreeType2, FT_Outline_Get_Bitmap);
	REG_FUNC(cell_FreeType2, FT_Outline_Get_CBox);
	REG_FUNC(cell_FreeType2, FT_Outline_GetInsideBorder);
	REG_FUNC(cell_FreeType2, FT_Outline_Get_Orientation);
	REG_FUNC(cell_FreeType2, FT_Outline_GetOutsideBorder);
	REG_FUNC(cell_FreeType2, FT_Outline_New);
	REG_FUNC(cell_FreeType2, FT_Outline_Render);
	REG_FUNC(cell_FreeType2, FT_Outline_Reverse);
	REG_FUNC(cell_FreeType2, FT_Outline_Transform);
	REG_FUNC(cell_FreeType2, FT_Outline_Translate);
	REG_FUNC(cell_FreeType2, FT_Realloc);
	REG_FUNC(cell_FreeType2, FT_Remove_Module);
	REG_FUNC(cell_FreeType2, FT_Render_Glyph);
	REG_FUNC(cell_FreeType2, FT_Request_Size);
	REG_FUNC(cell_FreeType2, FT_RoundFix);
	REG_FUNC(cell_FreeType2, FT_Select_Charmap);
	REG_FUNC(cell_FreeType2, FT_Select_Size);
	REG_FUNC(cell_FreeType2, FT_Set_Charmap);
	REG_FUNC(cell_FreeType2, FT_Set_Char_Size);
	REG_FUNC(cell_FreeType2, FT_Set_Debug_Hook);
	REG_FUNC(cell_FreeType2, FT_Set_MM_Blend_Coordinates);
	REG_FUNC(cell_FreeType2, FT_Set_MM_Design_Coordinates);
	REG_FUNC(cell_FreeType2, FT_Set_Pixel_Sizes);
	REG_FUNC(cell_FreeType2, FT_Set_Renderer);
	REG_FUNC(cell_FreeType2, FT_Set_Transform);
	REG_FUNC(cell_FreeType2, FT_Set_Var_Blend_Coordinates);
	REG_FUNC(cell_FreeType2, FT_Set_Var_Design_Coordinates);
	REG_FUNC(cell_FreeType2, FT_Sfnt_Table_Info);
	REG_FUNC(cell_FreeType2, FT_Sin);
	REG_FUNC(cell_FreeType2, FT_Stream_OpenGzip);
	REG_FUNC(cell_FreeType2, FT_Stream_OpenLZW);
	REG_FUNC(cell_FreeType2, FT_Stroker_BeginSubPath);
	REG_FUNC(cell_FreeType2, FT_Stroker_ConicTo);
	REG_FUNC(cell_FreeType2, FT_Stroker_CubicTo);
	REG_FUNC(cell_FreeType2, FT_Stroker_Done);
	REG_FUNC(cell_FreeType2, FT_Stroker_EndSubPath);
	REG_FUNC(cell_FreeType2, FT_Stroker_Export);
	REG_FUNC(cell_FreeType2, FT_Stroker_ExportBorder);
	REG_FUNC(cell_FreeType2, FT_Stroker_GetBorderCounts);
	REG_FUNC(cell_FreeType2, FT_Stroker_GetCounts);
	REG_FUNC(cell_FreeType2, FT_Stroker_LineTo);
	REG_FUNC(cell_FreeType2, FT_Stroker_New);
	REG_FUNC(cell_FreeType2, FT_Stroker_ParseOutline);
	REG_FUNC(cell_FreeType2, FT_Stroker_Rewind);
	REG_FUNC(cell_FreeType2, FT_Stroker_Set);
	REG_FUNC(cell_FreeType2, FT_Tan);
	REG_FUNC(cell_FreeType2, FT_Vector_From_Polar);
	REG_FUNC(cell_FreeType2, FT_Vector_Length);
	REG_FUNC(cell_FreeType2, FT_Vector_Polarize);
	REG_FUNC(cell_FreeType2, FT_Vector_Rotate);
	REG_FUNC(cell_FreeType2, FT_Vector_Transform);
	REG_FUNC(cell_FreeType2, FT_Vector_Unit);
});
